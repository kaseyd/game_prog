﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;

namespace Game_Programming_Project
{
    class Animation
    {

        /// <summary>
        /// Constructs a new animation.
        /// </summary>        
        public Animation(Texture2D texture, float frameTime, bool isLooping)
        {
            this.texture = texture;
            this.frameTime = frameTime;
            this.isLooping = isLooping;
        }


        /// <summary>
        /// The sprite sheet to be used in the animation
        /// </summary>
        public Texture2D Texture
        {
            get { return texture; }
        }
        Texture2D texture;


        /// <summary>
        /// Duration of time to show each frame
        /// </summary>
        public float FrameTime
        {
            get { return frameTime; }
        }
        float frameTime;


        /// <summary>
        /// Determines if the animation should play once, or loop
        /// </summary>
        public bool IsLooping
        {
            get { return isLooping; }
        }
        bool isLooping;


        /// <summary>
        /// Gets the number of frames in the animation
        /// </summary>
        public int FrameCount
        {
            get { return Texture.Width / FrameWidth; }
        }


        /// <summary>
        /// Gets the width of a frame in the animation
        /// </summary>
        public int FrameWidth
        {
            // Assume square frames.
            get { return Texture.Height; }
        }


        /// <summary>
        /// Gets the height of a frame in the animation
        /// </summary>
        public int FrameHeight
        {
            get { return Texture.Height; }
        }

    }
}
